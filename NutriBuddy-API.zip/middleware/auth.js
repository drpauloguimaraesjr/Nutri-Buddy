const { auth } = require('../config/firebase');

/**
 * Middleware to verify Firebase Auth tokens
 * Used to protect routes that require authentication
 * Also accepts webhook secret for N8N compatibility
 */
const verifyToken = async (req, res, next) => {
  try {
    // First, check if webhook secret is provided (for N8N)
    const secret = process.env.WEBHOOK_SECRET;
    const providedSecret = req.headers['x-webhook-secret'];
    
    console.log('🔐 [AUTH] Checking authentication:', {
      hasSecret: !!secret,
      providedSecret: providedSecret ? '***' : 'none',
      hasAuthHeader: !!req.headers.authorization
    });
    
    if (secret && providedSecret && providedSecret === secret) {
      console.log('✅ [AUTH] Webhook secret validated');
      // Webhook secret is valid, create a mock user for N8N
      req.user = {
        uid: 'n8n-service',
        email: 'n8n-test@nutribuddy.com',
        isServiceAccount: true
      };
      return next();
    }

    // Otherwise, try Firebase token authentication
    const token = req.headers.authorization?.split('Bearer ')[1];

    if (!token) {
      return res.status(401).json({
        error: 'No token provided',
        message: 'Authentication required. Provide either Authorization: Bearer token or x-webhook-secret header.'
      });
    }

    // Verify the token with Firebase
    const decodedToken = await auth.verifyIdToken(token);
    
    // Attach user info to request
    req.user = {
      uid: decodedToken.uid,
      email: decodedToken.email,
      ...decodedToken
    };

    next();
  } catch (error) {
    console.error('Token verification error:', error.message);
    return res.status(401).json({
      error: 'Invalid token',
      message: 'Authentication failed'
    });
  }
};

/**
 * Optional middleware for webhook validation
 * Used for N8N webhook security
 */
const verifyWebhook = (req, res, next) => {
  const secret = process.env.WEBHOOK_SECRET;
  
  // If no secret configured, skip validation
  if (!secret) {
    return next();
  }

  const providedSecret = req.headers['x-webhook-secret'];

  if (!providedSecret || providedSecret !== secret) {
    return res.status(403).json({
      error: 'Invalid webhook secret',
      message: 'Unauthorized request'
    });
  }

  next();
};

module.exports = {
  verifyToken,
  verifyWebhook
};

