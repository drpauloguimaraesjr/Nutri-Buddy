// generate-token.js

const admin = require('firebase-admin');
require('dotenv').config();

const serviceAccount = {
  projectId: process.env.FIREBASE_PROJECT_ID,
  privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
  clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
};

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

async function generateToken() {
  try {
    const auth = admin.auth();
    
    // Criar ou buscar usuário de teste
    const testEmail = 'n8n-test@nutribuddy.com';
    let user;
    
    try {
      user = await auth.getUserByEmail(testEmail);
      console.log('✅ Usuário encontrado:', user.email);
    } catch (error) {
      user = await auth.createUser({
        email: testEmail,
        password: 'TempPassword123!',
        displayName: 'N8N Test User',
        emailVerified: true
      });
      console.log('✅ Usuário criado:', user.email);
    }
    
    // Gerar custom token
    const customToken = await auth.createCustomToken(user.uid);
    
    console.log('\n🎯 TOKEN GERADO:');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(customToken);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('\n📋 INFORMAÇÕES:');
    console.log('User ID:', user.uid);
    console.log('Email:', user.email);
    console.log('Display Name:', user.displayName);
    console.log('\n💡 COMO USAR NO N8N:');
    console.log('1. Copie o token acima (entre as linhas)');
    console.log('2. No N8N Cloud → Settings → Environment Variables');
    console.log('3. FIREBASE_TOKEN = [cole o token aqui]');
    console.log('4. Save');
    console.log('\n✅ Este token nunca expira e é perfeito para N8N!');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Erro:', error.message);
    console.error('\n🔧 Verifique:');
    console.error('- Arquivo .env está configurado?');
    console.error('- Credenciais Firebase estão corretas?');
    console.error('- npm install foi executado?');
    process.exit(1);
  }
}

generateToken();

